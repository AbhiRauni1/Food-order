package com.example.me.tajserver.Interface;

import android.view.View;

/**
 * Created by me on 19-01-2018.
 */

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
