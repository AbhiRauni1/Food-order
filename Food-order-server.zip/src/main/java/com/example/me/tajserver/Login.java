package com.example.me.tajserver;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.me.tajserver.Model.Common;
import com.example.me.tajserver.Model.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.rengwuxian.materialedittext.MaterialEditText;

public class Login extends AppCompatActivity {
    private Button logbtn;
    private EditText editphone,editpassword;

    FirebaseDatabase db;
    DatabaseReference users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        editpassword = (MaterialEditText)findViewById(R.id.editpassword);
        editphone = (MaterialEditText)findViewById(R.id.editphone);
        logbtn = (Button)findViewById(R.id.logbtn);

        //Init Firebase
        db = FirebaseDatabase.getInstance();
        users = db.getReference("User");

        logbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    signInUser(editphone.getText().toString(),editpassword.getText().toString());
            }
        });

    }

    private void signInUser(final String phone, String password) {
        final ProgressDialog mDialog = new ProgressDialog(Login.this);
        mDialog.setMessage("Please Wait...");
        mDialog.show();

        final String localphone = phone;
        final String localpassword = password;
        users.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
            if(dataSnapshot.child(localphone).exists()){
                mDialog.dismiss();
                User user = dataSnapshot.child(localphone).getValue(User.class);
                user.setPhone(localphone);
                if(Boolean.parseBoolean(user.getIsStaff()))  //if staff is true
                    {
                        if(user.getPassword().equals(localpassword)){
                            Intent home = new Intent(Login.this,Menu.class);
                            Common.currentUser = user;
                            startActivity(home);
                            finish();
                        }
                        else
                            Toast.makeText(Login.this,"Wrong Password !",Toast.LENGTH_SHORT).show();
                   }
                   else
                    Toast.makeText(Login.this,"Please Login With Staff Account",Toast.LENGTH_SHORT).show();
              }
              else{
                    mDialog.dismiss();
                    Toast.makeText(Login.this,"User not exist in Database ",Toast.LENGTH_SHORT).show();
               }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }


}
