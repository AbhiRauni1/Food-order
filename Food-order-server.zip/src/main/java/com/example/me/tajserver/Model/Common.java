package com.example.me.tajserver.Model;

import com.example.me.tajserver.Model.User;

/**
 * Created by me on 21-01-2018.
 */

public class Common {
    public static User currentUser;

    public static final String UPDATE = "Update";
    public static final String DELETE = "Delete";
}
