package com.example.me.tajserver.Model;

/**
 * Created by me on 16-01-2018.
 */

public class Food {
    private String Name, Image, MenuId, Description, Price;

    public Food() {
    }

    public Food(String name, String image, String menuId, String description, String price) {
        Name = name;
        Image = image;
        MenuId = menuId;
        Description = description;
        Price = price;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getMenuId() {
        return MenuId;
    }

    public void setMenuId(String menuId) {
        MenuId = menuId;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }
}