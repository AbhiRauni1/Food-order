package com.example.me.tajserver;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.me.tajserver.Interface.ItemClickListener;
import com.example.me.tajserver.Model.Category;
import com.example.me.tajserver.Model.Common;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;


public class list extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DatabaseReference myRef;
    FirebaseRecyclerAdapter<Category,CategoryViewHolder> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        myRef = FirebaseDatabase.getInstance().getReference().child("/categories");
        recyclerView = (RecyclerView)findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

         adapter = new FirebaseRecyclerAdapter<Category, CategoryViewHolder>(
                Category.class,
                R.layout.individual_row,
                CategoryViewHolder.class,
                myRef

        ) {
            @Override
            protected void populateViewHolder(CategoryViewHolder viewHolder, Category model, final int position) {
            viewHolder.setTitle(model.getName());
            viewHolder.setImage(model.getImage());

            viewHolder.imageview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(list.this, FoodList.class);
                    intent.putExtra("CategoryId",adapter.getRef(position).getKey());
                    startActivity(intent);
                }
            });
            }


        };
         adapter.notifyDataSetChanged(); //refresh data if have data changed
        recyclerView.setAdapter(adapter);
    }
    public static class CategoryViewHolder extends RecyclerView.ViewHolder implements
        View.OnCreateContextMenuListener{
        TextView text_name;
        ImageView imageview;
        private ItemClickListener itemClickListener;


        public CategoryViewHolder(View itemView) {
            super(itemView);
            text_name=(TextView)itemView.findViewById(R.id.name);
            imageview=(ImageView)itemView.findViewById(R.id.imageview);

            itemView.setOnCreateContextMenuListener(this);

        }

        public void setTitle(String name) {
        text_name.setText(name);
        }

        public void setImage(String image) {
            Picasso.with(itemView.getContext())
                    .load(image)
                    .into(imageview);
        }



        @Override
        public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
            contextMenu.setHeaderTitle("Select the action");

            contextMenu.add(0,0,getAdapterPosition(), Common.UPDATE);
            contextMenu.add(0,1,getAdapterPosition(), Common.DELETE);

        }
    }
}
